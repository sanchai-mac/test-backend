package msgpack

import (
	"github.com/shamaton/msgpack/v2/def"
)

// Error is used in all msgpack error as the based error.
var Error = def.ErrMsgpack
