// Package fasthttpproxy provides SOCKS5 and HTTP proxy support for fasthttp.
package fasthttpproxy
